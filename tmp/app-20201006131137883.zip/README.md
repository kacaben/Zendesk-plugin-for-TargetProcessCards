# App name:
Create Targetprocess tickets from Zendesk

## Author:
Katerina Benova

## Description

Information needed for creating TP ticket is prefilled in the form and sent to Targetprocess webhook in Automation rules.
Agents are mapped to TP Owners (new agents must be added manually into switch)

Another automation rule checks every newly created ticket and if the Zendesk ID is present, webhook is sent to Zapier.
Zapier uses M. Kebrt's account to update the Zendesk ticket with the TP ticket ID and a comment.

### Install settings (manifest.json):

Parameter for mapping Agents to Targetprocess OwnerID in format {"Joe Doe":13, "Jane Doe":74,...} - default value, new agents can be added.
Parameters webhookBug and webhookReq URLs are set as default values.

### The following information is displayed:

* Subject - title of TP ticket
* Organization name
* Project (requests are automatically created in "Product requests" project)
* Severity (ignored in Requests)
* Customer Needs Informing
* Release Notes (ignored in Requests)
* Tags

Please submit bug reports to kb@memsource.com Pull requests are welcome.

### Developer note
Zendesk's ZAT is not working with ruby 2.7. and it's not possible to create the App package. Use ZCLI (beta) instead
https://develop.zendesk.com/hc/en-us/articles/360050791614-Introducing-ZCLI-The-Zendesk-Command-Line-Interface-Beta
zcli apps:package .
